<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>虎扑</title>
    <meta name="Keywords" content="虎扑,hupu,体育,篮球,足球,游戏电竞,步行街,运动装备" />
    <meta name="Description" content="虎扑是一个认真而有趣的社区，每天有众多JRs在虎扑分享自己对篮球、足球、游戏电竞、运动装备、影视、汽车、数码、情感等一切人和事的见解，热闹、真实、有温度。" />
    <meta name="360_ssp_verify" content="f4e761c0b1a4cf40a3f55fcaee72c5fa" />
    <meta name="baidu_ssp_verify" content="e3f4e0942a0319bac3a649ac35e11f39">
    <meta name="baidu_union_verify" content="ea23d975545251234628427c7101a0e4">
    <meta name="tencent-site-verification" content="ca9b722103ae35c45de5e477b38ed5b5"/>
    <link rel="dns-prefetch" href="//shihuo.hupucdn.com" />
    <link rel="dns-prefetch" href="//t1.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//v1.liangle.cn" />
    <link rel="dns-prefetch" href="//w1.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//w2.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//w4.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//w3.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//soccer.hupucdn.com" />
    <link rel="dns-prefetch" href="//www.hupucdn.com" />
    <link rel="dns-prefetch" href="//b1.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//b3.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//img1.hupucdn.com" />
    <link rel="dns-prefetch" href="//img2.hupucdn.com" />
    <link rel="dns-prefetch" href="//i3.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//i2.hoopchina.com.cn" />
    <link rel="dns-prefetch" href="//i1.hoopchina.com.cn" />
	<link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.hupu.com" />
    <meta name="apple-itunes-app" content="app-id=906632439" />
<link rel="shortcut icon" href="//b3.hoopchina.com.cn/common/favicon.ico" />
<link type="text/css" rel="stylesheet" href="//b3.hoopchina.com.cn/common/common-v1.css" />
<script src="//b3.hoopchina.com.cn/web/module/dace/1.0.0/dace.js"></script> 
<script src="//b3.hoopchina.com.cn/common/common-v1.js"></script>
    <meta property="qc:admins" content="2217337617605056375" />
    <script>
        !(function(win){if(/android|iphone|ipod|windows\sphone/.test(navigator.userAgent.toLowerCase())&&document.cookie.indexOf("__nmj")==-1){win.location.href='https://m.hupu.com'}})(window);
    </script>
            <script type="text/javascript" src="//b1.hoopchina.com.cn/common/jquery-1.6.js?v=201612271534"></script>
    <script type='text/javascript' src='//b3.hoopchina.com.cn/web/widget/material/2015/2/ckplayer/ckplayer.js?v=20150602' charset='utf-8'></script>
    <link rel="stylesheet" type="text/css" media="screen" href="//b3.hoopchina.com.cn/web/channel/www/css/hupu/index.min.css?v=201612271534" />
    <style>
        .hp-mainNav-A .item-col3{width:148px;}
    </style>
        <script type="text/javascript" src="//b3.hoopchina.com.cn/web/channel/www/js/hupu/homepage/index.js?v=201612271534"></script>
    <!-- new google-head begin-->
    <script type='text/javascript'>
        var googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
    </script>
    <script type='text/javascript'>
        googletag.cmd.push(function() {
            // googletag.defineSlot('/1016953/hupu_index728x90_2', [728, 90], 'div-gpt-ad-1442459674416-0').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index728x90_5', [728, 90], 'div-gpt-ad-1442459674416-1').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index728x90_7', [728, 90], 'div-gpt-ad-1442459674416-2').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_ndex_rightabovevote_240x200', [240, 200], 'div-gpt-ad-1442459674416-3').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu-index-rightbottom-200x200', [200, 200], 'div-gpt-ad-1442459674416-4').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index_rightundervote240x240', [240, 240], 'div-gpt-ad-1442459674416-5').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index_1x1_half', [1, 1], 'div-gpt-ad-1442459674416-6').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index_1x1_dx', [1, 1], 'div-gpt-ad-1442459674416-7').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index_1x1', [1, 1], 'div-gpt-ad-1442459674416-8').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index_kaluli_240x240', [240, 240], 'div-gpt-ad-1442459674416-9').addService(googletag.pubads());

            googletag.defineSlot('/1016953/hupu_index_728x90_3', [728, 90], 'div-gpt-ad-1442459674416-10').addService(googletag.pubads());
            googletag.defineSlot('/1016953/hupu_index_rightbottom_240x200', [240, 200], 'div-gpt-ad-1442459674416-11').addService(googletag.pubads());

            googletag.pubads().enableSingleRequest();
            googletag.enableServices();
        });
    </script>
    <!-- new google-head end -->
</head>
<body>
<div id="hp-topbarNav">
	<div class="hp-topbarNav-bd">
		<ul class="hp-quickNav">
			<li class="mobileWeb"><a href="javascript:void(0)" onclick="hp_quick_touch()"><i class="ico-mobile"></i>手机虎扑</a></li>
			<li class="line">|</li>
			<li class="mobileclientDown"><a class="red" href="https://mobile.hupu.com/?_r=globalNav" target="_blank">虎扑客户端</a></li>
			<li class="line">|</li>
			<li class="hp-dropDownMenu topFollowBlog">
				<a href="javascript:void(0)" class="hp-set">关注虎扑<s class="setArrow"></s></a>
				<div class="hp-drapDown followLayer">
					<a class="weibo" target="_blank" href="https://weibo.com/liangle4u"><i class="hp-ico-weibo"></i>新浪微博</a>
					<a class="weixin" target="_blank" href="https://voice.hupu.com/other/1581560.html"><i class="hp-ico-weixin"></i>官方微信</a>
					<a class="instagram" target="_blank" href="https://voice.hupu.com/other/1634334.html"><i class="hp-ico-instagram"></i>Instagram</a>
				</div>
			</li>
		</ul>
		<div class="hp-topLogin-info"></div>
	</div>
</div>
<!--topbarNav ent-->
<!--header star-->
<div class="hp-header">
	<div class="hp-logo">
		<a title="虎扑" href="https://www.hupu.com/"><img alt="虎扑" src="https://b3.hoopchina.com.cn/images/logo2017/v1/hp_logo_sports.png" /></a>
	</div>
	<div class="hp-mainNav hp-mainNav-A">
		<div class="hp-mainNav-bd">
        <div class="item-col item-col1">
			    <b><a href="https://soccer.hupu.com/">足球</a></b>
				<a href="https://soccer.hupu.com/china/" class="col-text-1">中超</a>
				<a href="https://soccer.hupu.com/england/">英超</a><br />
				<a href="https://soccer.hupu.com/spain/">西甲</a>
				<a href="https://soccer.hupu.com/germany/">德甲</a>
				<a href="https://soccer.hupu.com/italy/">意甲</a>
			</div>
			<div class="item-col item-col2">
				<b><a href="https://nba.hupu.com/">篮球</a></b>
				<a href="https://nba.hupu.com/">NBA</a>
				<a style="padding-left:14px;" href="https://cba.hupu.com/">CBA</a><br />
				<a href="http://zb.hupu.com/" target="_blank">装备</a>
				<a href="http://www.liangle.com" target="_blank">路人王</a>
				<a href="https://photo.hupu.com/" target="_blank"  style="margin-left: 10px;">图片</a>
			</div>


			<div class="item-col item-col4" style="position:relative">
                <b><a href="https://bbs.hupu.com/" target="_blank">社区</a></b>
                <a href="https://bbs.hupu.com/all-gambia" target="_blank">步行街</a>
                <a href="https://bbs.hupu.com/ent" target="_blank" style="margin:0 13px;">影视</a>
                <a href="https://gg.hupu.com" target="_blank">电竞</a>
                <a href="https://bbs.hupu.com/digital" target="_blank" style="margin-left:12px;margin-right:21px;">数码</a>
                <span class="hp-dropDownMenu hp-moreNav">
					<a class="hp-set" href="javascript:void(0)">更多<s class="setArrow"></s></a>
					<span class="hp-drapDown hp-moreNav-drapDown">
					    <a href="http://ymq.hupu.com" target="_blank">羽毛球</a>
						<a href="http://outdoor.hupu.com" target="_blank">户外</a>
						<a href="http://xgame.hupu.com" target="_blank">xgames</a>
						<a href="http://tennis.hupu.com" target="_blank">网球</a>
						<s class="arrow-top"><s class="arrowbd"></s></s>
					</span>
				</span>
			</div>
			<div class="item-col item-col5">
				<b><a href="http://www.shihuo.cn/" target="_blank">识货</a></b>
				<a href="http://www.shihuo.cn/tuangou" target="_blank">团购</a>
                <a href="http://www.shihuo.cn/haitao" target="_blank"  style="padding-left:10px;">海淘</a>
                <a href="https://shop311048929.taobao.com" target="_blank">优选</a><br />
                <a href="http://racing.hupu.com/">赛车</a>
                <a href="http://run.hupu.com/" target="_blank">健身</a>
				<a href="http://racing.hupu.com/motogp" target="_blank" style="margin-right:0;">MotoGP</a>
				<a style="margin-right:10px;" href="http://www.nflchina.com/" target="_blank">NFL官网</a>
			</div>
			<div class="item-col item-col6">
				<b><a href="http://www.fcbayern.cn/" target="_blank">拜仁官网</a></b>
				<span class="hp-dropDownMenu hp-moreNav">
                    <a class="hp-set" href="javascript:void(0)">合作官网<s class="setArrow"></s></a>
                    <span class="hp-drapDown" style="width:95px;left:-3px;">
					    <a href="http://cn.acmilan.com/" target="_blank">AC米兰</a>
						<a href="http://afp.hupu.com/" target="_blank">法新社体育</a>
						<a href="http://www.shanghaisharks.cn/" target="_blank">上海大鲨鱼</a>
						<a href="http://dongguan.hupu.com/" target="_blank">深圳烈豹</a>
						<a href="http://www.kunsunmedia.cn/" target="_blank">昆仑决官网</a>
                        <s class="arrow-top" style="left:25px;"><s class="arrowbd"></s></s>
                    </span>
                </span><br />
				  <a href="http://www.bundesliga.cn/" target="_blank">德甲官网</a>
				<a href="http://cn.liverpoolfc.com/" target="_blank"  style="margin-left:8px;">利物浦官网</a>
			</div>
		</div>
		<i class="hp-roundPoint-br-tl"></i>
		<i class="hp-roundPoint-br-tr"></i>
		<i class="hp-roundPoint-br-bl"></i>
		<i class="hp-roundPoint-br-br"></i>
	</div>
</div>
<div id="hp-wrap-adBg">
    
<!--VIDEO DOMAIN NAME CHANGE 2014-2015 -->





<div id="hupu-stream"><!--下拉广告div 请不要误删 --></div>
<div id="JOrient-banner"><!-- 定向广告 --></div>
<div class="ad980-60">
    <iframe width="980" height="60" scrolling="no" frameborder="0" allowtransparency="true" hspace="0" vspace="0" marginheight="0" marginwidth="0" src="//t1.hoopchina.com.cn/topn-v2.html#!zone-8201193"></iframe>
</div>
<div class="hp-wrap">
    <div class="cMain col-A">
        <div class="cFtLeft fsColumn mouseover">

            
            <!--new focus begin-->
            <div class="ui-slider" id="J_uiSlider">
                <div class="slider-pic">
                    <ul class="list">
                                                                                    <li><a target="_blank" href="https://bbs.hupu.com/28261457.html" title="欧青赛进球机器，他是德国苦苦寻找的强力中锋?"><img src="//www.hupucdn.com/uploads/hupu/focus/focus-large-5004_2019-07-03.jpg" alt="" /></a></li>
                                                                                                                <li><a target="_blank" href="https://bbs.hupu.com/28243899.html" title="曾被巴萨拒绝的刺头，会在尤文取得成功吗？"><img src="//www.hupucdn.com/uploads/hupu/focus/focus-large-2809_2019-07-03.jpg" alt="" /></a></li>
                                                                                                                <li><a target="_blank" href="https://bbs.hupu.com/28252860.html" title="封锁梅西向前传递，阿尔维斯这“老头”很能打"><img src="//www.hupucdn.com/uploads/hupu/focus/focus-large-8483_2019-07-03.jpg" alt="" /></a></li>
                                                                                                                <li><a target="_blank" href="https://bbs.hupu.com/28243816.html" title="18岁的德甲最佳新秀，他能成长为新拉莫斯吗？"><img src="//www.hupucdn.com/uploads/hupu/focus/focus-large-6166_2019-07-03.jpg" alt="" /></a></li>
                                                                                                                                                                                </ul>
                </div>
                <ul class="slider-text">
                                                                        <li class="active">
                                                                    <div class="text-bg">
                                        <h3 class="title"><a target="_blank" href="https://bbs.hupu.com/28261457.html">欧青赛进球机器，他是德国苦苦寻找的强力中锋?</a></h3>
                                        <div class="text">近期表现惊艳，他可以成为德国队锋线的救星吗？</div>
                                    </div>
                                                            </li>
                                                                                                <li >
                                                                    <div class="text-bg">
                                        <h3 class="title"><a target="_blank" href="https://bbs.hupu.com/28243899.html">曾被巴萨拒绝的刺头，会在尤文取得成功吗？</a></h3>
                                        <div class="text">攻守兼备的巴黎太子爷，拉比奥能在安联重新起航吗？</div>
                                    </div>
                                                            </li>
                                                                                                <li >
                                                                    <div class="text-bg">
                                        <h3 class="title"><a target="_blank" href="https://bbs.hupu.com/28252860.html">封锁梅西向前传递，阿尔维斯这“老头”很能打</a></h3>
                                        <div class="text">复盘巴阿战，36岁的阿尔维斯发挥决定性作用。</div>
                                    </div>
                                                            </li>
                                                                                                <li >
                                                                    <div class="text-bg">
                                        <h3 class="title"><a target="_blank" href="https://bbs.hupu.com/28243816.html">18岁的德甲最佳新秀，他能成长为新拉莫斯吗？</a></h3>
                                        <div class="text">进攻极具视野与天赋，未来仍有很多需要提高的地方。</div>
                                    </div>
                                                            </li>
                                                                                                                                                    </ul>
            </div>
            <script>
                $(document).ready(function(){
                    $('#J_uiSlider').slider();
                });
            </script>
            <!--new focus end -->

            <!--column star-->
            <div class="cBoxBr column ">
                <div class="cHd-A">
                    <h2>虎扑制造</h2>
                </div>
                <div class="bd" style="position: relative;">
                    
                                            <dl class="cDl-A">
                            <dt>
                                <a data-track="feature-1" target="_blank" href="https://bbs.hupu.com/28224310.html">
                                    <img class="lazyLoadImg" src="/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/feature/ft-05174_2019-07-03.jpg"  />
                                </a>
                            </dt>
                            <dd>
                                <h4><a data-track="feature-1" target="_blank" href="https://bbs.hupu.com/28224310.html">为什么活塞需要罗斯？</a></h4>
                            </dd>
                            <dd class="textInfo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;正当他被遗忘时，这位前MVP宣告了他的回归。</dd>
                        </dl>
                                            <dl class="cDl-A">
                            <dt>
                                <a data-track="feature-1" target="_blank" href="https://bbs.hupu.com/28238984.html">
                                    <img class="lazyLoadImg" src="/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/feature/ft-13764_2019-07-03.jpg"  />
                                </a>
                            </dt>
                            <dd>
                                <h4><a data-track="feature-1" target="_blank" href="https://bbs.hupu.com/28238984.html">肯巴-沃克亲笔：波士顿，让我们启程吧</a></h4>
                            </dd>
                            <dd class="textInfo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;波士顿，让我们九月再见。</dd>
                        </dl>
                    
                    <ul class="list">
                                                    <li>
                                <h3><a data-track="feature-2" target="_blank" href="https://bbs.hupu.com/28223181.html">简要分析篮网的签约</a></h3>
                            </li>
                                                    <li>
                                <h3><a data-track="feature-2" target="_blank" href="https://bbs.hupu.com/28224560.html">拉塞尔交易评级</a></h3>
                            </li>
                                            </ul>
                </div>
            </div>
            <!--column ent-->
        </div>
        <!--focusNews star-->
        <div class="cFtMiddle focusNews">
                                            <dl id="block_0" data-track-block="headnews-1-{{innerText}}">
                    <dt>
                        <em class="titIcon">NBA</em>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28274371.html">
                                                                                                                                    谁把凯尔特人推向悬崖？                            </a>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28254809.html">
                                                                                                                                    夏联：努力的人值得被奖赏                            </a>
                                            </dt>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28281632.html">
                                                                        伦纳德将不会在今日做出决定                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28282271.html">
                                                                        消息人士：国王不会裁掉费雷尔                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28281894.html">
                                                                        活塞正式签下新秀塞古-敦布亚                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28282201.html">
                                                                        消息人士：科沃尔和爵士没有联系                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://nba.hupu.com/draft/">
                                                                        2019新秀排名及资料介绍                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28281831.html">
                                                                        科比在社交媒体发布第四个女儿照片                                </a>
                                                            
                        </dd>
                    
                </dl>
                                            <dl id="block_1" data-track-block="headnews-2-{{innerText}}">
                    <dt>
                        <em class="titIcon">NBA</em>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28271728.html">
                                                                                                                                    杜兰特：当祈祷落幕时                            </a>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28271587.html">
                                                                                                                                    考利-斯坦能为勇士带来什么                            </a>
                                            </dt>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28282077.html">
                                                                        瓦兰：猛龙给我戒指肯定接受                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28282461.html">
                                                                        独行侠打算为赖特开出报价                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28282398.html">
                                                                        西亚卡姆更新Ins分享度假照                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28281508.html">
                                                                        小迈克尔-波特左膝盖扭伤，夏联成疑                                </a>
                                                            
                        </dd>
                    
                </dl>
                                            <dl id="block_2" data-track-block="headnews-3-{{innerText}}">
                    <dt>
                        <em class="titIcon">CBA</em>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28289733.html">
                                                                                                                                    17点播 国青VS拉脱维亚                            </a>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28271458.html">
                                                                                                                                    周鹏算不算是扣将？                            </a>
                                            </dt>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28277109.html">
                                                                        前青岛队外援约翰逊签约NBL球队                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28276231.html">
                                                                        丁彦雨航祝贺翟晓川爱女降生                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28276173.html">
                                                                        大学生运动会中国队不敌乌克兰                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28274763.html">
                                                                        CBA选秀训练营教练员名单公布                                </a>
                                                            
                        </dd>
                    
                </dl>
                                            <dl id="block_3" data-track-block="headnews-4-{{innerText}}">
                    <dt>
                        <em class="titIcon">足球</em>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28280148.html">
                                                                                                                                    官方：罗本宣布退役                            </a>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28279115.html">
                                                                                                                                    传奇门将布冯回归尤文图斯                            </a>
                                            </dt>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28276454.html">
                                                                        官方：马竞中场罗德里加盟曼城                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28273752.html">
                                                                        神灯回归！兰帕德任切尔西主帅                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28280443.html">
                                                                        官方：切尔西助教佐拉正式离队                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28279500.html">
                                                                        传博格巴希望为皇马和齐祖效力                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28281118.html">
                                                                        官方：曼联中场埃雷拉加盟巴黎                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28280903.html">
                                                                        尤文愿卖博努奇，曼城对他有意                                </a>
                                                            
                        </dd>
                    
                </dl>
                                            <dl id="block_4" data-track-block="headnews-5-{{innerText}}">
                    <dt>
                        <em class="titIcon">足球</em>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28245598.html">
                                                                                                                                    阿森纳财务报告解析                            </a>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28253245.html">
                                                                                                                                    拉什福德专访：想赢得欧冠                            </a>
                                            </dt>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28252042.html">
                                                                        热议：本届美洲杯阿根廷输在哪                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28250936.html">
                                                                        老当益壮，阿尔维斯的表现如何                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28253043.html">
                                                                        视频：女足摩根进球后展示招牌动作                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28252833.html">
                                                                        枪手新援马丁内利精彩集锦                                </a>
                                                            
                        </dd>
                    
                </dl>
                                            <dl id="block_5" data-track-block="headnews-6-{{innerText}}">
                    <dt>
                        <em class="titIcon">中超</em>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28268420.html">
                                                                                                                                    费莱尼因肘击禁赛3场                            </a>
                                                    <a target="_blank" class="" href="https://bbs.hupu.com/28276818.html">
                                                                                                                                    跟队：埃神胡睿宝互换东家                            </a>
                                            </dt>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28276938.html">
                                                                        卡帅：放没机会的球员出去锻炼                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28275086.html">
                                                                        记者：有些国脚仍对归化有抵触                                </a>
                                                            
                        </dd>
                                            <dd>
                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28268964.html">
                                                                        新闻官微博辟谣申花引进穆谢奎                                </a>
                                                                    <em class="line">|</em>
                                                            
                                <a class="" target="_blank" href="https://bbs.hupu.com/28279404.html">
                                                                        上观：绿地赔偿给花帅1.5亿元                                </a>
                                                            
                        </dd>
                    
                </dl>
                    </div>
    </div>
    <!--col-A ent-->

    <!--sidebar star-->
    <div class="sidebar ">
        <!--boxscore star-->
        <div class="boxscore">
            <ul class="tabTitle">
                <li class="cur tab" data-canvas="#matchContainer" data-type="important"><a href="javascript:">重大</a></li>
                <li class="tab" data-canvas="#matchContainer" data-type="basketball"><a href="javascript:">篮球</a></li>
                <li class="footLiW tab" data-canvas="#matchContainer" data-type="football"><a href="javascript:">足球</a></li>
            </ul>
            <div class="bd">
                <div id="matchContainer">
                    
<div class="mainScore">
  <div class="scorePaging"> 
        <a href="javascript:"
       data-date="2019-07-04"
       data-type="important" 
       data-canvas="#matchContainer" class="page prev"
       title="前一天" class="prev noPrev">前一天</a>                
    <span class="curTime">7月5日</span>             
    <a href="javascript:"
       data-date="2019-07-06"
       data-type="important"
       data-canvas="#matchContainer" class="page next"
       title="后一天" class="next noNext">
       后一天
    </a> 
  </div>
   
   <div class="noneScore">今日无重大比赛</div>
      </div>
                </div>
                <!--mainScore ent-->
                <div id="js-txtAd" class="bmTextAd"></div>
            </div>
        </div>

        

                <!--boxscore ent-->


        <!--识货广告位begin-->
        
                    <div class="cBox-A voteIndex">
                <div class="cHd-C">
                    <h2><a href="http://www.shihuo.cn/?ad_from=ty&amp;ad_page=sy&amp;ad_pos=cp" target="_blank">识货每日爆款</a></h2>
                </div>
                                <div class="starchina_info bd">
                    <div class="left" style="width: 218px;margin-bottom: 5px;">
                        <a href="http://www.shihuo.cn/youhui/319097.html" target="_blank" style="height: 120px;display: inline-block;width: 100%;">
                            <img height="61" width="70" src="https://w4.hoopchina.com.cn/7b/3c/6a/7b3c6a312df6508e6be4406fa5ffd9de002.png" style="width: 218px;height: 120PX;padding:0;margin:0;border:none">
                            <p style="position: absolute;z-index: 99; width: 218px;margin-top: -25px; color: #fff;background: rgba(0,0,0,.5);height: 25px;line-height: 25px;text-indent: 10px;">领券防身：各大商城每日必领神券</p>
                        </a>
                    </div>
                    <div class="clear"></div>
                    <ul class="shihuo_li">
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/column/143.html">好物指南：精选优质好物 优惠指南</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/column/300.html">趣买小站：新鲜有趣list 陪你fun</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/youhui/535594.html">Under Armour Showstopper￥303</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/youhui/535669.html">李宁夏季紧身针织运动服￥149</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/youhui/535678.html">DR.WU 玻尿酸基础护理礼盒￥129</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/youhui/533783.html">Nike Dunk SB Brown Camo ￥899</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/youhui/535638.html">Chinism 夏季条纹Polo衫￥68</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/youhui/534997.html">ThinkPad E480 14英寸笔记本￥4399</a>
                        </li>
                                                <li>
                            <a target="_blank" href="http://www.shihuo.cn/youhui/535666.html">飞利浦（PHILIPS）电动剃须刀￥228</a>
                        </li>
                                            </ul>
                </div>
            </div>

        
        <!-- 2014世界杯倒计时-->
                        <div class="cBox-A huputv">
            <div class="cHd-C">
                <h2><a target="_blank" href="http://www.liangle.com">路人王</a></h2>
            </div>
            <div class="bd">
                <ul class="list" id="huputvlist">
                </ul>
            </div>
        </div>
                <div class="ad240-200">
            <!-- /1016953/hupu_ndex_rightabovevote_240x200 -->
            <div id='div-gpt-ad-1442459674416-3' style='height:200px; width:240px;overflow:hidden;'>
                <script type='text/javascript'>
                    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1442459674416-3'); });
                </script>
            </div>
        </div>
                                <div class="mrBt8 ad361-240-240">
            <!-- /1016953/hupu_index_rightundervote240x240 -->
            <div id='div-gpt-ad-1442459674416-5' style='height:234px; width:234px;overflow:hidden;'>
                <script type='text/javascript'>
                    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1442459674416-5'); });
                </script>
            </div>
        </div>
                <!--   <div class="ad240-295">
              <div class="bd">
               hupu_indexright_101x103_1 上左
              <script type='text/cjs'>
              GA_googleFillSlotWithSize("ca-pub-1024337685431355", "hupu_indexright_101x103_1", 101, 130);
              </script>
              </div>
              <div class="bd">
               hupu_indexright_101x103_2 上右
              <script type='text/cjs'>
              GA_googleFillSlotWithSize("ca-pub-1024337685431355", "hupu_indexright_101x103_2", 101, 130);
              </script>
              </div>
              <div class="bd">
               hupu_indexright_101x103_3 下左
              <script type='text/cjs'>
              GA_googleFillSlotWithSize("ca-pub-1024337685431355", "hupu_indexright_101x103_3", 101, 130);
              </script>
              </div>
              <div class="bd">
               hupu_indexright_101x103_4 下右
              <script type='text/cjs'>
              GA_googleFillSlotWithSize("ca-pub-1024337685431355", "hupu_indexright_101x103_4", 101, 130);
              </script>
              </div>
            </div>    -->
        <!--gallery star-->
                <!--gallery ent-->
                <div class="ad200-200">
            <!-- /1016953/hupu-index-rightbottom-200x200 -->
            <div id='div-gpt-ad-1442459674416-4' style='height:200px; width:200px;overflow:hidden;'>
                <script type='text/javascript'>
                    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1442459674416-4'); });
                </script>
            </div>

        </div>
                                            </div>
    <!--sidebar ent-->
    <!--col-B star-->
    <div class="clearLt col-B">
        <!--voice star-->
        <div class="cBoxBr cFtLeft voice">
            <div class="cHd-A">
                <h2>动态</h2>
            </div>
            <div class="hd">
                <div class="voiceBox">
                    <div class="voiceList" id="voiceList">
                                                    <ul class="list">
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/130717/2510b70e131f7658bca9f597be6cd9de54234b0c.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    埃因霍温官网：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450521.html" target="_blank">
                                                    官方：瓦伦西亚与拉托续约4年，并租借至埃因霍温</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/140217/48bae325a61fbf996e14d7b3b539f02d88698e28.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    新浪微博：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/china/2450520.html" target="_blank">
                                                    记者：穆谢奎不会加盟申花，申花找不到引进他的理由</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/150608/fb2f7a61aaba5fc5a1f80446ae778736abd0bb31.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    德比郡官网：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450519.html" target="_blank">
                                                    官方：前荷兰国脚科库担任德比郡新帅</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/170426/b516208f3936631d5537f26b728b976d60164ba5.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    eldesmarque：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450518.html" target="_blank">
                                                    西媒：租期结束，赫塞即将离开巴黎，正式转会加盟贝蒂斯</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/120731/a10abd8a088092dcc2d5a474416216ef102c0a36.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    太阳报：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450517.html" target="_blank">
                                                    醉了，阿里与女友海边度假不胜酒力，被两名安保搀扶离开</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/120929/7e7312f0de64a19c9accc66e599979f7de4bd860.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    天空体育：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450516.html" target="_blank">
                                                    名宿：范戴克在场上几乎无所不能，他是难得的领袖</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/160906/378334ecad373ac7bed05171b29c133d7f73adc8.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    虎扑：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/other/2450515.html" target="_blank">
                                                    年轻定义时代，BUFF点燃激情，北京汽车智达X3预售价5.99万元-9.99万元</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/120813/8cae14accb158b24a8338b2825c54016d346add7.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    NBC：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/nba/2450514.html" target="_blank">
                                                    美名记：选秀大会时森林狼曾想用科温顿向上交易选秀权</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                            </ul>
                                                    <ul class="list">
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/130717/ac72ca4adb7e2426561375cd4852929296c65fcc.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    RMC Sport：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450513.html" target="_blank">
                                                    布冯：我对巴黎，只有感谢！那里的球迷是现象级的</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/170717/ce11b1d745995f86ad6b196a317b82fe5b8eb421.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    Instagram：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/nba/2450512.html" target="_blank">
                                                    黑夜里的酷帅男孩！德罗赞更新Ins发布自己的照片</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/120814/e13ec448fcd9d6b06b955d04122b3f832dc37b67.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    世界体育报：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450511.html" target="_blank">
                                                    世体：德容已经通过巴萨体检</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/140217/48bae325a61fbf996e14d7b3b539f02d88698e28.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    新浪微博：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/china/2450510.html" target="_blank">
                                                    一图流：武磊参加西班牙人季前体检</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/180716/74af64b35cb3564c99dfbbcffa2c8c3fcee54729.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    虎扑：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450509.html" target="_blank">
                                                    瓦格纳祝福罗本：离去已是传奇，终于有空来中国找我玩了</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/150612/3203594fd2ccce1455863c3fb7420a887a4c1074.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    Sportsnaut：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/nba/2450508.html" target="_blank">
                                                    雄鹿计划与萨纳西斯-阿德托昆博签下2年300万合同</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/140217/48bae325a61fbf996e14d7b3b539f02d88698e28.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    新浪微博：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/china/2450507.html" target="_blank">
                                                    申花官方：崔康熙正式出任球队新主帅</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/180717/8447e0a8669dfc2546d80ad0a9e64e756ffaa6b7.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    虎扑：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/china/2450506.html" target="_blank">
                                                    佩雷拉：明天与申花的比赛会让四名外援都做好准备</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                            </ul>
                                                    <ul class="list">
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/180716/74af64b35cb3564c99dfbbcffa2c8c3fcee54729.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    虎扑：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450504.html" target="_blank">
                                                    有情有义！阿贾克斯买下世体整个广告页，只为祝德容好运</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/120910/f69d785e4306e1bf82ecb4a2e784f24c5deda9c6.gif" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    IBTimes：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/nba/2450503.html" target="_blank">
                                                    帕金斯：杜兰特从未于格林的事件中恢复过来</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/170717/ce11b1d745995f86ad6b196a317b82fe5b8eb421.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    Instagram：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/nba/2450502.html" target="_blank">
                                                    艾弗森更新社交媒体晒出与好友游玩照片</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/180716/74af64b35cb3564c99dfbbcffa2c8c3fcee54729.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    虎扑：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450501.html" target="_blank">
                                                    霸气！伊布身披印错姓名球衣梅开二度，助洛杉矶2球取胜</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/140217/48bae325a61fbf996e14d7b3b539f02d88698e28.jpg" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    新浪微博：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/china/2450500.html" target="_blank">
                                                    记者：申花俱乐部证实从未与阿瑙托维奇有过接触</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c2.hoopchina.com.cn/uploads/star/newuser/120731/c2085b9049bfc50e0618d846d52125b66b5f401c.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    BBC：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450499.html" target="_blank">
                                                    前FIFA主席布拉特将发起诉讼：要求归还被没收的60块手表</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/120730/e3a78e4f3a60a56d4c7d36f28e395c669216cbcf.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    Twitter：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/nba/2450498.html" target="_blank">
                                                    马刺夏季联赛名单：朗尼-沃克领衔，贝基-哈蒙任主帅</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                                    <li>
                                        <dl>
                                            <dt>
                                                <img src="//c1.hoopchina.com.cn/uploads/star/newuser/120929/7e7312f0de64a19c9accc66e599979f7de4bd860.png" />
                                            </dt>
                                            <dd>
                                                <h3 class="gray"  style="font-weight:bold;">
                                                    天空体育：
                                                </h3>

                                                <a data-track="voice-message" href="https://voice.hupu.com/soccer/2450497.html" target="_blank">
                                                    老雷：从未见过像兰帕德那样训练如此刻苦之人</a>
                                            </dd>
                                        </dl>
                                    </li>
                                                            </ul>
                                            </div>
                </div>
                <script type="text/javascript">
                    voiceList.init("voiceList");
                </script>
                <!--      <ul class="newsList">-->
                <!--        -->                <!--          <li>-->
                <!--            <h3>-->
                <!--              <a href="--><!--" target="_blank" data-track="feature-2">--><!--</a>-->
                <!--            </h3>-->
                <!--          </li>       -->
                <!--        -->                <!--      </ul>-->
            </div>
            <!--voice ent-->
        </div>

        <div class="cFtMiddle">
            <!--bbsTopic star-->
            <div class="cBoxBr mrBt8 bbsTopic">
                                
                    
                    <div class="cHd-B">
                                                    <h2>
                                <a data-track="column-篮球话题-1" target="_blank" href="https://bbs.hupu.com/vote">篮球话题</a></h2>
                            <a data-track="column-篮球话题-2" target="_blank" href="https://bbs.hupu.com/vote" class="cMore">最近204个热议话题»</a>
                                            </div>

                    <div class="bd" >
                        <ul class="list">
                                                            <li>
                                    <a data-track="topic-篮球话题" target="_blank" href="https://bbs.hupu.com/28281633.html">Carter：伦纳德将不会在今日做出决定</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                50亮414回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-篮球话题" target="_blank" href="https://bbs.hupu.com/28281772.html">湖人有意自由球员后卫特雷-伯克 </a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                11亮88回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-篮球话题" target="_blank" href="https://bbs.hupu.com/28284409.html">铁林：手机停机了，没有和伦纳德打电话 </a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                29亮121回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-篮球话题" target="_blank" href="https://bbs.hupu.com/28282077.html">瓦蓝：如果猛龙给我戒指，那我肯定接受</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                11亮86回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-篮球话题" target="_blank" href="https://bbs.hupu.com/28283478.html">圣安东尼奥当地出现了招募考辛斯广告牌</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                10亮107回复                                    </em>
                                </li>
                                                    </ul>

                                            </div>
                
                    
                    <div class="cHd-B">
                                                    <h2>
                                <a data-track="column-足球话题-1" target="_blank" href="https://bbs.hupu.com/topic">足球话题</a></h2>
                            <a data-track="column-足球话题-2" target="_blank" href="https://bbs.hupu.com/topic" class="cMore">最近705个热议话题»</a>
                                            </div>

                    <div class="bd" >
                        <ul class="list">
                                                            <li>
                                    <a data-track="topic-足球话题" target="_blank" href="https://bbs.hupu.com/28285598.html">国外网友制作兰帕德不是出任蓝军主帅，只是回家了</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                2回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-足球话题" target="_blank" href="https://bbs.hupu.com/28289712.html">武磊体检照，感觉回国之后胖了一圈？</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                2亮28回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-足球话题" target="_blank" href="https://bbs.hupu.com/28289350.html">罗本凭什么不能称为“内切第一人”。</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                12亮42回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-足球话题" target="_blank" href="https://bbs.hupu.com/28284686.html">上帝创造的集锦，伊布拉希莫维奇职业生涯10佳球</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                12亮82回复                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-足球话题" target="_blank" href="https://bbs.hupu.com/28286071.html">硬汉归来，凯恩正式成为NFL推广大使</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                10回复                                    </em>
                                </li>
                                                    </ul>

                                            </div>
                
                    
                    <div class="cHd-B">
                                                    <h2>
                                <a data-track="column-体育场话题-1" target="_blank" href="https://bbs.hupu.com/sports">体育场话题</a></h2>
                            <a data-track="column-体育场话题-2"  target="_blank" href="https://bbs.hupu.com/sports" class="cMore">最近852个热议话题»</a>

                                            </div>

                    <div class="bd" >
                        <ul class="list">
                                                            <li>
                                    <a data-track="topic-体育场话题" target="_blank" href="https://voice.hupu.com/other/2240215.html">巴萨中国足球纪录片《世茂旋风少年》首映</a>
                                    <em class="ft84">
                                                                                            <!-- 调用足球话题 -->
                                                                                    </em>
                                </li>
                                                            <li>
                                    <a data-track="topic-体育场话题" target="_blank" href="https://bbs.hupu.com/20142879.html">唯一的橄榄球中文资讯App上线了</a>
                                    <em class="ft84">
                                                                                                                                                                            </em>
                                </li>
                                                    </ul>

                                            </div>
                            </div>
            <!--bbsTopic ent-->
            <div class="cBoxBr bbsTopic" >
                <div class="cHd-B">
                    <h2>
                        <a data-track="column-步行街-1"  target="_blank" href="https://bbs.hupu.com/bxj">步行街</a></h2>
                    <a data-track="column-步行街-2"  href="https://bbs.hupu.com/bxj" target="_blank" class="cMore">最近171个热议话题»</a>
                </div>
                <div class="bd">
                    <ul class="list">
                                                    <li><a data-track="topic-步行街" target="_blank" href="https://bbs.hupu.com/28284136.html">抖音上这段模仿NBA十大场面什么水平</a>
                                <em class="ft84">
                                                                            50亮725回复
                                                                    </em>
                            </li>
                                                    <li><a data-track="topic-步行街" target="_blank" href="https://bbs.hupu.com/28286599.html">支付宝宣布拿出10亿支持中国女足发展</a>
                                <em class="ft84">
                                                                            50亮374回复
                                                                    </em>
                            </li>
                                                    <li><a data-track="topic-步行街" target="_blank" href="https://bbs.hupu.com/28285622.html">我是95年，父母突然通知我要当姐姐了</a>
                                <em class="ft84">
                                                                            50亮1246回复
                                                                    </em>
                            </li>
                                                    <li><a data-track="topic-步行街" target="_blank" href="https://bbs.hupu.com/28286981.html">为什么小时候没空调我们也不觉得热？</a>
                                <em class="ft84">
                                                                            50亮307回复
                                                                    </em>
                            </li>
                                            </ul>
                </div>
                <ul class="textAd">
                                                                                                                            <li style="height: 17px;overflow: hidden;">
                                                                                                                                                                        <a data-track="topic-广告链" target="_blank" title="欧仕派男士沐浴露x女神大赛火热进行中" href="https://goto.hupu.com/?a=goClick&id=18085">欧仕派男士沐浴露x女神大赛火热进行中</a>
                                                 <em style="padding: 0 3px;">|</em>                                                                                                                                                                                 <a data-track="topic-广告链" target="_blank" title="" href=""></a>
                                                                                                                                                                                                        </li>
                                                                                                                <li style="height: 17px;overflow: hidden;">
                                                                                                                                                                        <a data-track="topic-广告链" target="_blank" title="提升幸福感的电视替代品—坚果J7S" href="https://bbs.hupu.com/28021024.html">提升幸福感的电视替代品—坚果J7S</a>
                                                 <em style="padding: 0 3px;">|</em>                                                                                                                                                                                 <a data-track="topic-广告链" target="_blank" title="分享你的爱情故事，赢奖品" href="https://bbs.hupu.com/28004021.html">分享你的爱情故事，赢奖品</a>
                                                                                                                                                                                                        </li>
                                                                                                                                            </ul>

            </div>

        </div>
    </div>
    <!--col-B ent-->
        <!-- <div class="clearLt ad720-90"> -->
        <!-- /1016953/hupu_index728x90_2 -->
        <!-- <div id='div-gpt-ad-1442459674416-0' style='height:90px; width:728px;overflow:hidden;'>
            <script type='text/javascript'>
                googletag.cmd.push(function() { googletag.display('div-gpt-ad-1442459674416-0'); });
            </script>
        </div> -->
    <!-- </div> -->
        <!--col-F star-->
    <div class="clearLt cBoxBr col-F">
        <div class="cHd-A">
            <h2><a data-track="column-中国足球" href="https://soccer.hupu.com/china/" target="_blank">中国足球</a></h2>
            <div class="hdLink"><a href="https://voice.hupu.com/china" target="_blank">新闻</a>|<a href="https://bbs.hupu.com/all-csl" target="_blank">论坛</a></div>
        </div>
        <div class="bd">
            <div class="cFtLeft cVideoBox">
                                    <dl class="cDl-A">
                        <dt><a target="_blank" href="https://bbs.hupu.com/19249537.html">
                                <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//soccer.hupucdn.com/2017-05-21/a567411796861db6_2017-05-21.jpg"  /></a>
                        </dt>
                        <dd>
                            <h4><a target="_blank" href="https://bbs.hupu.com/19249537.html">恒大2-1苏宁：接近英超的快节奏战役</a></h4>
                        </dd>
                        <dd class="textInfo">　　两队代表中超最高水平，于汉超替补登场亮眼，恒大领先后仍敢于压上进攻。</dd>
                    </dl>
                    <ul class="list-A">
                                                                                                                                            <li><a target="_blank" href="https://bbs.hupu.com/19180421.html">恒大年龄结构全面解析</a></li>
                                                                                <li><a target="_blank" href="https://bbs.hupu.com/19229489.html">恶搞段子：恐怖的拉维奇</a></li>
                                                                                <li><a target="_blank" href="https://bbs.hupu.com/19223610.html">致安塔尔：后郑智时代真核</a></li>
                                                                                <li><a target="_blank" href="https://bbs.hupu.com/19231772.html">南斯拉夫足球的中国情结</a></li>
                                            </ul>

                             <!-- 中国足球-->
            </div>
            <div class="cFtMiddle" data-track-block="middle-column-chinasoccer">
                
                    <ul class="list-B">
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/china-soccer">中国足球</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28289954.html">申花6年8个教练，崔康熙能够长待申花，并带来改变吗？</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/china-soccer">中国足球</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28289658.html">[流言板]一图流：武磊参加西班牙人季前体检</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/sipgfc">上海上港</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28289486.html">[流言板]佩雷拉：明天与申花的比赛会让四名外援都做好准备</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/china-soccer">中国足球</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28288259.html">阮公凤加盟比甲圣图尔登，是否看好他的旅欧前景（比照镰田大地）</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/china-soccer">中国足球</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28283144.html">大家能接受首发场上十一人里有几个外国人？</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/china-soccer">中国足球</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28279723.html">[流言板]武汉杯：中国U14点球1-4负朝鲜，将与马来西亚争第三</a>
                            </li>
                                            </ul>
                            </div>
        </div>
    </div>
    <!--col-F ent-->
    <div class="clearLt cBoxBr col-E">
        <div class="cHd-A">
            <h2><a data-track="column-国际足球" href="https://soccer.hupu.com" target="_blank">国际足球</a></h2>
            <div class="hdLink"><a href="https://voice.hupu.com/soccer" target="_blank">新闻</a>|<a href="https://g.hupu.com/soccer/" target="_blank">比赛</a>|<a href="https://bbs.hupu.com/all-soccer" target="_blank">论坛</a></div>
        </div>
        <div class="bd">
            <div class="cFtLeft cVideoBox">
                <div class="cHd-D">
                    <h3><a href="https://soccer.hupu.com/england/" target="_blank">英超</a></h3>
                    <div class="hdLink"><em class="line">|</em><a href="https://soccer.hupu.com/teams/135" target="_blank">曼城</a><em class="line">|</em><a href="https://soccer.hupu.com/teams/150" target="_blank">曼联</a><em class="line">|</em><a href="https://soccer.hupu.com/teams/161" target="_blank">阿森纳</a><em class="line">|</em><a href="https://soccer.hupu.com/teams/116" target="_blank">切尔西</a><em class="line">|</em><a href="https://soccer.hupu.com/teams/118" target="_blank">利物浦</a></div>
                </div>
                                    <ul class="cDottedLine list-B" style="padding-bottom:10px; padding-left:9px;">
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450517.html">醉了，阿里与女友海边度假不胜酒力，被两名安保搀扶离开</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450516.html">名宿：范戴克在场上几乎无所不能，他是难得的领袖</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450499.html">前FIFA主席布拉特将发起诉讼：要求归还被没收的60块手表</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450497.html">老雷：从未见过像兰帕德那样训练如此刻苦之人</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450482.html">皇马与阿森纳谈判巴斯克斯转会，标价3500万欧元</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450477.html">回声报：违规接触球员，红军要求 FIFA调查阿德坎耶转会</a>
                            </li>
                        
                    </ul>
                
                <div class="cHd-D">
                    <h3><a href="https://soccer.hupu.com/spain/" target="_blank">西甲</a></h3>
                    <div class="hdLink"><em class="line">|</em><a href="https://soccer.hupu.com/teams/252" target="_blank">巴萨</a><em class="line">|</em><a href="https://soccer.hupu.com/teams/210" target="_blank">皇马</a><em class="line">|</em><a href="https://soccer.hupu.com/teams/245" target="_blank">瓦伦西亚</a><em class="line">|</em><a href="https://soccer.hupu.com/teams/209" target="_blank">塞维利亚</a></div>
                </div>
                                    <ul class="list-B" style="padding-bottom:10px; padding-left:9px;">
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450518.html">西媒：租期结束，赫塞即将离开巴黎，正式转会加盟贝蒂斯</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450511.html">世体：德容已经通过巴萨体检</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450504.html">有情有义！阿贾克斯买下世体整个广告页，只为祝德容好运</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450499.html">前FIFA主席布拉特将发起诉讼：要求归还被没收的60块手表</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450494.html">叒当老板！皮克收购瓜帅母队，并将终止该队与皇马的合作</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450492.html">每体：拉马西亚教练团队主体都在，只是正常人员更替</a>
                            </li>
                        
                    </ul>
                                <!--原国际足球图片中心-->
            </div>
            <div class="cFtMiddle" data-track-block="middle-column-soccer">


                <div class="cHd-D">
                    <h3><a href="https://soccer.hupu.com/germany/" target="_blank">德甲</a></h3>
                    <div class="hdLink">
                        <em class="line">|</em><a target="_blank" href="https://soccer.hupu.com/teams/358">拜仁</a>
                        <em class="line">|</em><a target="_blank" href="https://soccer.hupu.com/teams/273">多特蒙德</a>
                        <em class="line">|</em><a target="_blank" href="https://soccer.hupu.com/teams/357">沙尔克04</a>
                        <em class="line">|</em><a target="_blank" href="https://soccer.hupu.com/teams/351">勒沃库森</a>
                    </div>
                </div>
                                    <ul class="cDottedLine list-B" style="padding-bottom:10px; padding-left:9px;">
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450499.html">前FIFA主席布拉特将发起诉讼：要求归还被没收的60块手表</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450470.html">调皮！狼堡告别罗本：就这样成了唯一让你被罚下的德甲队</a>
                            </li>
                        
                    </ul>
                
                <div class="cHd-D">
                    <h3><a target="_blank" href="https://soccer.hupu.com/italy/" target="_blank">意甲</a></h3>
                    <div class="hdLink">
                        <em class="line">|</em><a href="https://soccer.hupu.com/teams/215" target="_blank">AC米兰</a>
                        <em class="line">|</em><a href="https://soccer.hupu.com/teams/268" target="_blank">国际米兰</a>
                        <em class="line">|</em><a href="https://soccer.hupu.com/teams/264" target="_blank">尤文图斯</a>
                        <em class="line">|</em><a href="https://soccer.hupu.com/teams/254" target="_blank">罗马</a>
                    </div>
                </div>
                
                    <ul class="cDottedLine list-B" style="padding-bottom:13px; padding-left:9px;">
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450499.html">前FIFA主席布拉特将发起诉讼：要求归还被没收的60块手表</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450489.html">迪马济奥：沙拉维同意加盟申花，罗马要价2000万欧以上</a>
                            </li>
                                            </ul>
                
                <!-- 世界杯 20140428 changeTO UEFA 20151019 -->
                <div class="cHd-D">
                                            <h3><a target="_blank" href="https://soccer.hupu.com/uefa/">欧冠</a></h3>
                        <div class="hdLink">
                            <em class="line">|</em><a href="https://voice.hupu.com/soccer/tag/2011.html" target="_blank">新闻</a>
                            <em class="line">|</em><a href="https://soccer.hupu.com/uefa/schedule.php" target="_blank">赛程</a>
                            <em class="line">|</em><a href="https://soccer.hupu.com/uefa/table.php" target="_blank">积分榜</a>
                        </div>
                                    </div>
                <ul class="list-B">
                                                                        <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450333.html">官方：切尔西助理教练佐拉正式离队</a>
                                <em class="ft84">
                                                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450324.html">恢复得不错，奇克Ins晒健身房锻炼照</a>
                                <em class="ft84">
                                                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2450318.html">德赛利：兰帕德能胜任蓝军主帅，球员生涯的经历会帮到他</a>
                                <em class="ft84">
                                                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2448710.html">瓜帅：内马尔回巴萨很棒，他们欧冠出局不是因为梅西</a>
                                <em class="ft84">
                                                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2448634.html">英媒评英超历史20大外援：C罗榜首力压亨利</a>
                                <em class="ft84">
                                                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/soccer/2447985.html">AZP：有英超球队曾高薪邀请阿扎尔，但他不为所动</a>
                                <em class="ft84">
                                                                                                        </em>
                            </li>
                                                            </ul>
            </div>
        </div>
    </div>
        <!-- /1016953/hupu_index_728x90_3 -->
    <div id='div-gpt-ad-1442459674416-10' style='height:90px; width:728px;overflow:hidden;margin-bottom: 8px;' class="clearLt">
        <script type='text/javascript'>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1442459674416-10'); });
        </script>
    </div>
        <!--col-C star-->
    <div class="clearLt cBoxBr col-C">
        <div class="cHd-A">
            <h2><a data-track="column-nba"  href="https://nba.hupu.com" target="_blank">NBA</a></h2>
            <div class="hdLink"><a href="https://voice.hupu.com/nba" target="_blank">新闻</a>
                |<a href="https://nba.hupu.com/games" target="_blank">比赛</a>
                |<a href="https://bbs.hupu.com/all-nba" target="_blank">论坛</a></div>
        </div>
        <div class="bd">
            <div class="cFtLeft cVideoBox">
                <div class="cHd-D">
                    <h3><a href="https://nba.hupu.com/teams/warriors" target="_blank">勇士</a></h3>
                    <div class="hdLink"><em class="line">|</em><a href="https://voice.hupu.com/nba/tag/2982.html" target="_blank">新闻</a><em class="line">|</em><a href="https://bbs.hupu.com/warriors" target="_blank">论坛</a></div>
                </div>
                <ul class="cDottedLine list-B" style="padding-bottom:10px; padding-left:9px;">
                                            <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450505.html">[视频] 关键时刻又稳又狠！伊格达拉上赛季十佳球回顾</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450503.html">帕金斯：杜兰特从未于格林的事件中恢复过来</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450481.html">杰伦-罗斯：我认为勇士下赛季能进季后赛</a>
                        </li>
                    
                </ul>
                <div class="cHd-D">
                    <h3><a href="https://nba.hupu.com/teams/cavaliers" target="_blank">骑士</a></h3>
                    <div class="hdLink"><em class="line">|</em><a href="https://voice.hupu.com/nba/tag/3023.html" target="_blank">新闻</a><em class="line">|</em><a href="https://bbs.hupu.com/cavaliers" target="_blank">论坛</a></div>
                </div>

                <ul class="list-B" style="padding-bottom:10px; padding-left:9px;">
                                            <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450466.html">[视频]暴扣目不暇接！夏季联赛第三天扣篮集锦</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450348.html">贾斯廷-霍勒迪正考虑湖人快船公牛等多支有意他的球队</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450298.html">小凯文-波特因臀屈肌伤势预计不会出战赌城夏季联赛</a>
                        </li>
                                    </ul>
                <!--原NBA新闻图片中心-->
            </div>
            <div class="cFtMiddle" data-track-block="middle-column-nba">

                    <div class="cHd-D">
                        <h3><a href="https://nba.hupu.com/teams/rockets" target="_blank">火箭</a></h3>
                        <div class="hdLink"><em class="line">|</em><a href="https://voice.hupu.com/nba/tag/811.html" target="_blank">新闻</a><em class="line">|</em><a href="https://bbs.hupu.com/rockets" target="_blank">论坛</a></div>
                    </div>

                    <ul class="cDottedLine list-B" style="padding-bottom:10px; padding-left:9px;">
                                                <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450415.html">莫雷晒哈登夏季联赛旧照：谁会是下一个</a>
                        </li>
                                                <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450401.html">莫雷分享灯泡12年伦敦奥运会帮助美国夺金照庆祝独立日</a>
                        </li>
                                                <li>
                            <a target="_blank" href="https://voice.hupu.com/nba/2450360.html">莫雷发布保罗当年参加夏季联赛旧照：下一个是谁</a>
                        </li>
                                            </ul>
                                    <div class="cHd-D">
                        <h3><a href="https://nba.hupu.com/teams/lakers" target="_blank">湖人</a></h3>
                        <div class="hdLink"><em class="line">|</em><a href="https://voice.hupu.com/nba/tag/846.html" target="_blank">新闻</a><em class="line">|</em><a href="https://bbs.hupu.com/lakers" target="_blank">论坛</a></div>
                    </div>
                    <ul class="list-B" style="padding-bottom:10px; padding-left:9px;">
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/nba/2450488.html">杜德利：如果伦纳德加盟，湖人会拥有更强的三巨头</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/nba/2450479.html">[视频]粉丝心情！SnoopDogg唱歌劝说伦纳德加入湖人</a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://voice.hupu.com/nba/2450478.html">慈世平预测下赛季：拉塞尔对勇士是很好的补充，冠军属于湖人</a>
                            </li>
                                            </ul>
                                            </div>
        </div>
    </div>
    <!--col-C ent-->
    <!--col-D star-->
    <style type="text/css">
        .cVideoBox h3 {padding: 0;}
    </style>
    <div class="clearLt cBoxBr col-D">
        <div class="cHd-A">
            <h2><a data-track="column-cba" href="https://cba.hupu.com" target="_blank">CBA</a></h2>
            <div class="hdLink">
                <a href="https://voice.hupu.com/cba" target="_blank">新闻</a>
                |<a href="https://bbs.hupu.com/all-cba" target="_blank">论坛</a>
            </div>
        </div>
        <div class="bd">
            <div class="cFtLeft cVideoBox">
                <dl class="cDl-A">
                    <dt>
                        <a target="_blank" href="https://bbs.hupu.com/19913041.html">
                            <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//w1.hoopchina.com.cn/74/5c/ab/745cab90ed298dbddf013f049b85e6ad002.png" />
                        </a>
                    </dt>
                    <dd>
                        <h4><a target="_blank" href="https://bbs.hupu.com/19913041.html">常林回归，新赛季北京内线质的飞跃？</a></h4>
                    </dd>
                    <dd class="textInfo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;JRs怎么看常林回归北京这笔签约？他能使新赛季北京薄弱的内线起到质的飞跃？</dd>
                </dl>
                <ul class="list-A">
                    <li><a target="_blank" href="https://bbs.hupu.com/19913636.html">如何评价热身赛孟铎的表现？</a></li><li><a target="_blank" href="https://bbs.hupu.com/19900382.html">从纸面分析长三角五支球队</a></li><li><a target="_blank" href="https://bbs.hupu.com/19902454.html">如何评价姚时代的首次选秀？</a></li><li><a target="_blank" href="https://bbs.hupu.com/19904128.html">红队战绩差是阵容导致的？</a></li>                </ul>
                <!--原cba新闻图片中心-->
            </div>
            <div class="cFtMiddle" data-track-block="middle-column-cba">

                <ul class="list-B">
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/cba">中国篮球</a>
                            <em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28290250.html">中国男篮参加NBA夏季联赛首战 你会放弃来之不易的周末么？</a>                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/cba">中国篮球</a>
                            <em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28275373.html">[流言板]北京男篮新赛季或更换主场，放弃五棵松迁回首钢篮球馆</a>                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/cba">中国篮球</a>
                            <em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28289912.html">中国男篮的4场夏季联赛都是李克解说，然后他发的微博什么水平？</a>                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/cba">中国篮球</a>
                            <em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28285938.html">【图集】姚明抵达拉斯维加斯机场，督战男篮NBA夏季联赛练兵</a>                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/cba">中国篮球</a>
                            <em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28290015.html">如果中国队夏季联赛第一场，满足以下条件，送闲置iPhone6sp一台</a>                        </li>
                                    </ul>
            </div>
        </div>
    </div>
    <!--col-D ent-->
    <!--col-E star-->
    <!--col-E ent-->
        <div class="clearLt ad720-90">
        <!-- /1016953/hupu_index728x90_5 -->
        <div id='div-gpt-ad-1442459674416-1' style='height:90px; width:728px;overflow:hidden;'>
            <script type='text/javascript'>
                googletag.cmd.push(function() { googletag.display('div-gpt-ad-1442459674416-1'); });
            </script>
        </div>
    </div>
        <!--col-G star-->
    <div class="clearLt cBoxBr col-G">
        <div class="cHd-A">
            <h2><a data-track="column-运动装备" href="https://bbs.hupu.com/gear" target="_blank">运动装备</a></h2>
            <div class="hdLink"><a href="http://zb.hupu.com/" target="_blank">鞋柜</a>|<a href="https://bbs.hupu.com/gear" target="_blank">装备区</a>|<a href="https://bbs.hupu.com/c2c" target="_blank">交易区</a>|<a href="https://bbs.hupu.com/2" target="_blank">二手</a>|<a href="https://bbs.hupu.com/jersey" target="_blank">球衣</a>|<a href="https://bbs.hupu.com/726" target="_blank">潮流</a></div>
        </div>
        <div class="bd">
            <div class="cFtLeft cVideoBox">
                                    <!--focus star-->
                    <div class="focusImg-shihuo" id="J_focusImgShihuo">
                        <div class="bigImg">
                            <ul>
                                                                    <li>
                                        <a href="http://t.shihuo.cn/604.html" target="_blank" title="识货团购-服饰-专场">
                                            <img src="//shihuo.hupucdn.com/uploads/trade/groupon/interface/201903/0817/1a1b245d87b3822af43abebddfc04975.png" alt="识货团购-服饰-专场">
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="http://www.shihuo.cn/tuangou/list/p-0-%E7%AF%AE%E7%90%83%E9%9E%8B" target="_blank" title="Adidas Harden LS 2 Buckle哈登2麂皮全掌BOOST缓震篮球鞋AQ0020">
                                            <img src="//shihuo.hupucdn.com/def/20190226/c2775aaa0079ab220682ed10217314581551113949.jpg?imageView2/1/w/315/h/185" alt="Adidas Harden LS 2 Buckle哈登2麂皮全掌BOOST缓震篮球鞋AQ0020">
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="http://www.shihuo.cn/tuangou/list/p-0-%E8%B7%91%E9%9E%8B" target="_blank" title="Adidas Ultra Boost ub4.0 纯白 黑白四代 BB6149 BB6494 AC8025">
                                            <img src="//shihuo.hupucdn.com/def/20190305/f282d4a7f69b14c96e7c61833f4fb0dd1551753771.jpg?imageView2/1/w/315/h/185" alt="Adidas Ultra Boost ub4.0 纯白 黑白四代 BB6149 BB6494 AC8025">
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="http://www.shihuo.cn/tuangou/list/p-0-%E4%BC%91%E9%97%B2%E9%9E%8B" target="_blank" title="李宁夜光闪卡外穿凉拖">
                                            <img src="//shihuo.hupucdn.com/def/20190522/36fc7169aca4df5bd05c7bdd2256a7001558513625.jpg?imageView2/1/w/315/h/185" alt="李宁夜光闪卡外穿凉拖">
                                        </a>
                                    </li>
                                                            </ul>
                        </div>
                        <div class="smallImg">
                            <ul>
                                                                    <li class="first active">
                                        <div class="progressBar">
                                            <div class="progressBar-bd"></div>
                                        </div>
                                        <div class="pic">
                                            <img src="//shihuo.hupucdn.com/uploads/trade/groupon/interface/201903/0817/1a1b245d87b3822af43abebddfc04975.png" alt="识货团购-服饰-专场">
                                        </div>
                                    </li>
                                                                    <li >
                                        <div class="progressBar">
                                            <div class="progressBar-bd"></div>
                                        </div>
                                        <div class="pic">
                                            <img src="//shihuo.hupucdn.com/def/20190226/c2775aaa0079ab220682ed10217314581551113949.jpg?imageView2/1/w/315/h/185" alt="Adidas Harden LS 2 Buckle哈登2麂皮全掌BOOST缓震篮球鞋AQ0020">
                                        </div>
                                    </li>
                                                                    <li >
                                        <div class="progressBar">
                                            <div class="progressBar-bd"></div>
                                        </div>
                                        <div class="pic">
                                            <img src="//shihuo.hupucdn.com/def/20190305/f282d4a7f69b14c96e7c61833f4fb0dd1551753771.jpg?imageView2/1/w/315/h/185" alt="Adidas Ultra Boost ub4.0 纯白 黑白四代 BB6149 BB6494 AC8025">
                                        </div>
                                    </li>
                                                                    <li >
                                        <div class="progressBar">
                                            <div class="progressBar-bd"></div>
                                        </div>
                                        <div class="pic">
                                            <img src="//shihuo.hupucdn.com/def/20190522/36fc7169aca4df5bd05c7bdd2256a7001558513625.jpg?imageView2/1/w/315/h/185" alt="李宁夜光闪卡外穿凉拖">
                                        </div>
                                    </li>
                                                            </ul>
                        </div>

                        <ul class="content-text">
                                                            <li class="active">
                                    <div class="info">
                                        虎扑识货团购</span>
                                    </div>
                                    <div class="title-text">
                                        <a target="_blank" href="http://t.shihuo.cn/604.html" title="识货团购-服饰-专场">识货团购-服饰-专场</a>
                                    </div>
                                </li>
                                                            <li>
                                    <div class="info">
                                                                                <span class="price">￥429.00</span>
                                        <span class="participate">219人已参与&nbsp;虎扑识货团购</span>
                                    </div>
                                    <div class="title-text">
                                        <a target="_blank" href="http://www.shihuo.cn/tuangou/list/p-0-%E7%AF%AE%E7%90%83%E9%9E%8B" title="Adidas Harden LS 2 Buckle哈登2麂皮全掌BOOST缓震篮球鞋AQ0020">Adidas Harden LS 2 Buckle哈登2麂皮全掌BOO</a>
                                    </div>
                                </li>
                                                            <li>
                                    <div class="info">
                                                                                <span class="price">￥439.00</span>
                                        <span class="participate">296人已参与&nbsp;虎扑识货团购</span>
                                    </div>
                                    <div class="title-text">
                                        <a target="_blank" href="http://www.shihuo.cn/tuangou/list/p-0-%E8%B7%91%E9%9E%8B" title="Adidas Ultra Boost ub4.0 纯白 黑白四代 BB6149 BB6494 AC8025">Adidas Ultra Boost ub4.0 纯白 黑白四代 BB</a>
                                    </div>
                                </li>
                                                            <li>
                                    <div class="info">
                                                                                <span class="price">￥78.00</span>
                                        <span class="participate">48人已参与&nbsp;虎扑识货团购</span>
                                    </div>
                                    <div class="title-text">
                                        <a target="_blank" href="http://www.shihuo.cn/tuangou/list/p-0-%E4%BC%91%E9%97%B2%E9%9E%8B" title="李宁夜光闪卡外穿凉拖">李宁夜光闪卡外穿凉拖</a>
                                    </div>
                                </li>
                                                    </ul>
                    </div>
                    <script>
                        $(function(){
                            $("#J_focusImgShihuo").focusImg({
                                time : "8"
                            });
                        });
                    </script>
                    <!--focus ent-->
                            </div>

            <div class="cFtMiddle" data-track-block="middle-column-gears">
                <dl class="cDl-A">
                    <dt><a target="_blank" href="https://bbs.hupu.com/20513111.html"><img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//w2.hoopchina.com.cn/9f/b2/0c/9fb20c65238bffecdc27935b62eb13e1001.jpg"  /></a></dt>
                    <dd>
                        <h4><a target="_blank" href="https://bbs.hupu.com/20513111.html">Air Flight Huarache X Air Max Uptempo</a></h4>
                    </dd>
                    <dd class="textInfo">　　两双鞋都是在15年前后买的Retro，到手的时候已经是等了好久的折扣了，加起来1000出头一点。想着Kobe退役的时候写点啥，结果一放就放到今天了。</dd>
                </dl>
                <ul class="list-A">
                    <li><a target="_blank" href="http://bbs.hupu.com/16188488.html">毒APP微信公众等待你的关注</a></li><li><a target="_blank" href="https://bbs.hupu.com/19798896.html">PG1- Joker ID 小丑配色实物</a></li><li><a target="_blank" href="https://bbs.hupu.com/19806462.html">跟着内马尔去Flight Club买鞋</a></li><li><a target="_blank" href="https://bbs.hupu.com/19807082.html">分享一下暑假带回家的鞋子们</a></li>                </ul>
                <ul class="list-B">
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/gear">运动装备</a><em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28260267.html">AF1布克到货</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/gear">运动装备</a><em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28290069.html">T-MAC | 你存在于我最美好的年少</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/gear">运动装备</a><em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28283064.html">驭帅11low球员版</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/gear">运动装备</a><em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28289894.html">看看lbj颜值如何</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/gear">运动装备</a><em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28289481.html">曝光一个咸鱼奸商，以后大家别买他的鞋</a>
                        </li>
                                            <li>
                            <a target="_blank" href="https://bbs.hupu.com/gear">运动装备</a><em class="line">|</em>
                            <a target="_blank" href="https://bbs.hupu.com/28290244.html"></a>
                        </li>
                                    </ul>
            </div>
        </div>
    </div>
        <!--col-H star-->
        <!--col-I star-->
    <div class="clearLt cBoxBr col-I">
        <div class="cHd-A">
            <h2><a target="_blank" href="https://bbs.hupu.com/all-gambia">步行街</a></h2>
            <div class="hdLink">
                <a href="https://bbs.hupu.com/bxj" target="_blank">步行街主干道</a>
                |<a href="https://bbs.hupu.com/ent" target="_blank">影视区</a>
                |<a href="https://bbs.hupu.com/game" target="_blank">电竞区</a>
                |<a href="https://bbs.hupu.com/acg" target="_blank">ACG区</a>
                |<a href="https://bbs.hupu.com/cars" target="_blank">车友交流</a>
            </div>
        </div>
        <div class="bd" >
                        <div class="cFtLeft cVideoBox">
                <div class="cHd-D">
                </div>
                <!--focus star-->
                <div class="focusLeftImg">
                                        <div class="bigImg" id="box3_bigImg">
                        <ul>
                                                            <li>
                                    <a target="_blank" href="https://bbs.hupu.com/bxj">
                                        <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-large-7264_2017-03-28.jpg" alt="" />
                                    </a>
                                </li>
                                                            <li>
                                    <a target="_blank" href="https://bbs.hupu.com/game">
                                        <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-large-6198_2017-03-28.jpg" alt="" />
                                    </a>
                                </li>
                                                            <li>
                                    <a target="_blank" href="https://bbs.hupu.com/music">
                                        <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-large-5501_2017-03-28.jpg" alt="" />
                                    </a>
                                </li>
                                                            <li>
                                    <a target="_blank" href="https://bbs.hupu.com/ent">
                                        <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-large-9108_2017-03-28.jpg" alt="" />
                                    </a>
                                </li>
                                                    </ul>
                    </div>
                    <ul id="box3_smallImg" class="smallImg">
                                                    <li>
                                <s></s>
                                <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-thum-9025_2017-03-28.jpg"  />
                            </li>
                                                    <li>
                                <s></s>
                                <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-thum-3276_2017-03-28.jpg"  />
                            </li>
                                                    <li>
                                <s></s>
                                <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-thum-1812_2017-03-28.jpg"  />
                            </li>
                                                    <li>
                                <s></s>
                                <img class="lazyLoadImg" src="//b3.hoopchina.com.cn/images/hupu/noneImg.png" _src="//www.hupucdn.com/uploads/hupu/webgame/webgame-thum-115_2017-03-28.jpg"  />
                            </li>
                                            </ul>

                    <ul class="infoText box3_infoText">
                                                    <li>
                                <div class="bg">
                                    <h3><a href="#">步行街主干道</a></h3>
                                </div>
                            </li>
                                                    <li>
                                <div class="bg">
                                    <h3><a href="#">电竞区</a></h3>
                                </div>
                            </li>
                                                    <li>
                                <div class="bg">
                                    <h3><a href="#">音乐区</a></h3>
                                </div>
                            </li>
                                                    <li>
                                <div class="bg">
                                    <h3><a href="#">影视区</a></h3>
                                </div>
                            </li>
                                            </ul>

                    <ul class="textAbout box3_infoText">
                                                                            <li class="curr">逛虎扑步行街极易上瘾，请各位注意控制时间哟^_^</li>
                                                                                <li class="">虎扑电竞区，做最好的电竞讨论区！</li>
                                                                                <li class="">从古典到流行，从蓝调到爵士，从民乐到乡村，从摇滚到说唱，爱音乐、爱生活，感受这世上最美妙的食物！</li>
                                                                                <li class="">影海视界，一切尽在这里，一切皆有可能！</li>
                                                                        </ul>
                </div>
                <script type="text/javascript">
                    var box3 = new Focusimg({b:"box3_bigImg",s:"box3_smallImg",text:"box3_infoText"});
                </script>
            </div>
            <div class="cFtMiddle">
                <div class="cHd-D">
                    <h3><a data-track="middle-column-bxj" href="https://bbs.hupu.com/all-gambia" target="_blank">JRs正在热议</a></h3>
                </div>
                <ul class="list-B" data-track-block="middle-column-bxj">
                                                                        <li>
                                <a target="_blank" href="https://bbs.hupu.com/ent">影视</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28286193.html">刘德华说的这个话是不是真心话呢？</a>
                                <em class="ft84">
                                                                                    50亮
                                                                                                                            346人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/ent">影视</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28285019.html">成龙吊打黄日华，黄日华强行称打平</a>
                                <em class="ft84">
                                                                                    33亮
                                                                                                                            115人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/ent">影视</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28282786.html">复仇者联盟缺乏大规模清杂兵的人物</a>
                                <em class="ft84">
                                                                                    50亮
                                                                                                                            226人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/ent">影视</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28282626.html">吹一波雷佳音了，自身可塑性真的强</a>
                                <em class="ft84">
                                                                                    32亮
                                                                                                                            131人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/4856">娱乐圈</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28283642.html">新一代国民闺女赵今麦，你喜欢她吗</a>
                                <em class="ft84">
                                                                                    17亮
                                                                                                                            145人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/4856">娱乐圈</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28288477.html">胡可晒美照少女感十足，黄T短发清爽</a>
                                <em class="ft84">
                                                                                                                            1人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/acg">ACG</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28287015.html">如果顶上战争明哥开鸟笼会发生什么</a>
                                <em class="ft84">
                                                                                    20亮
                                                                                                                            77人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/acg">ACG</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28285620.html">路飞团是不是已经是很强的团队了？</a>
                                <em class="ft84">
                                                                                    10亮
                                                                                                                            71人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/digital">数码</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28285132.html">外媒爆光了iPhone 11的外观和细节</a>
                                <em class="ft84">
                                                                                    18亮
                                                                                                                            113人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/cars">车友交流</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28286235.html">亚洲龙出厂发动机仓里少6个螺丝！</a>
                                <em class="ft84">
                                                                                    15亮
                                                                                                                            78人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/4846">啥破图都有</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28283070.html">切记，不要把烟头扔到随便哪个洞里</a>
                                <em class="ft84">
                                                                                    50亮
                                                                                                                            172人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">热门</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28284055.html">跟富二代同时爱上了一个女孩，怎么办</a>
                                <em class="ft84">
                                                                                    8亮
                                                                                                                            78人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">热门</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28284186.html">B站敬汉卿应粉丝要求，喝7万元红酒！</a>
                                <em class="ft84">
                                                                                    50亮
                                                                                                                            317人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">热门</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28286693.html">清华这波录取通知书可谓十分简约低调</a>
                                <em class="ft84">
                                                                                    29亮
                                                                                                                            171人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">热门</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28287998.html">说唱界最强Diss之一！震动半个说唱圈</a>
                                <em class="ft84">
                                                                                    24亮
                                                                                                                            97人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">新鲜</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28284848.html">一年工资省下去趟美国看NBA，值吗？</a>
                                <em class="ft84">
                                                                                    49亮
                                                                                                                            694人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">新鲜</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28285902.html">第一次看到棒耍的比六小龄童还好的人</a>
                                <em class="ft84">
                                                                                    31亮
                                                                                                                            125人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">新鲜</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28283407.html">看了介绍，学化学的是不是很有前途？</a>
                                <em class="ft84">
                                                                                    48亮
                                                                                                                            382人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">新鲜</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28285698.html">今天给工地搬水泥的小哥，颜值啥水平</a>
                                <em class="ft84">
                                                                                    43亮
                                                                                                                            222人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">话题</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28285802.html">杨过用自己的浑厚内力助黄蓉打通经脉</a>
                                <em class="ft84">
                                                                                    46亮
                                                                                                                            127人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">话题</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28259888.html">晒下自己玩电脑的时候猫咪都在干嘛？</a>
                                <em class="ft84">
                                                                                    48亮
                                                                                                                            313人回复
                                                                        </em>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://bbs.hupu.com/bxj">话题</a>
                                <em class="line">|</em>
                                <a target="_blank" href="https://bbs.hupu.com/28284682.html">老婆不喜欢和我周围的有钱朋友接触！</a>
                                <em class="ft84">
                                                                                    9亮
                                                                                                                            104人回复
                                                                        </em>
                            </li>
                                                            </ul>
            </div>
        </div>
    </div>
    <!--col-I ent-->
        <div class="clearLt ad720-90 hp-mrBtNone">
        <!-- /1016953/hupu_index728x90_7 -->
        <div id='div-gpt-ad-1442459674416-2' style='height:90px; width:728px;overflow:hidden;'>
            <script type='text/javascript'>
                googletag.cmd.push(function() { googletag.display('div-gpt-ad-1442459674416-2'); });
            </script>
        </div>
    </div>
    </div>

<div id="skin-footer">
    <div class="hp-w hp-footerLinks">
        友情链接：
                    <a target="_blank" title="好123 " href="http://www.hao123.com/sports">好123</a>
                    <a target="_blank" title="凤凰体育 " href="http://sports.ifeng.com">凤凰体育</a>
                    <a target="_blank" title="中华网体育 " href="http://sports.china.com/">中华网体育</a>
                    <a target="_blank" title="趣运动-订场神器 " href="http://www.quyundong.com/">趣运动-订场神器</a>
                    <a target="_blank" title="途虎养车 " href="https://www.tuhu.cn">途虎养车</a>
                    <a target="_blank" title="心心App " href="https://www.xinxinapp.cn/">心心App</a>
                    <a target="_blank" title="章鱼直播 " href="http://www.zhangyu.tv?v=1">章鱼直播</a>
            </div>
        <div class="hp-footer">
                    <div class="hp-copyright">虎扑（上海）文化传播股份有限公司 <a href="https://www.hupu.com/icp.html" target="_blank">沪B2-20120042</a> <a target="_blank" href="http://beian.miit.gov.cn/">沪ICP备05037078号-13</a></div>
                    <div class="hp-copyright">
                    <img src="https://b3.hoopchina.com.cn/images/hupu/hupu_logo.png" style="padding-top:5px;padding-top: 2px\9;" /> - 
                    Copyright by 虎扑JRs &amp;
                    <a href="https://www.hupu.com/" target="_blank" title="虎扑">虎扑</a> -
                    <a href="https://m.hupu.com/" target="_blank">手机虎扑网</a> -
                    <a href="https://mobile.hupu.com/" target="_blank">虎扑App</a> -
                    <a href="https://www.hupu.com/policies/terms" target="_blank">服务协议</a> -
                    <a href="https://www.hupu.com/sitemap.html" target="_blank">网站地图</a> -
                    <a href="https://nba.hupu.com/" target="_blank" title="NBA">NBA</a> -
                    <a href="https://cba.hupu.com/" target="_blank" title="CBA">CBA</a>  -
                    <a href="https://soccer.hupu.com/" target="_blank" title="足球">足球</a> -
                    <a href="https://soccer.hupu.com/china/" target="_blank" title="中超">中超</a> -
                    <a href="http://racing.hupu.com/" target="_blank" title="赛车">赛车</a>  - <a href="http://huiti.hupu.com/" target="_blank" title="慧体网络">慧体网络</a>
                    </div>
                    <div class="securityPic">
                    <a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=31010902102201" target="_blank"><img src="https://b3.hoopchina.com.cn/images/hupu/wangbei.png" alt="上海公安备案"></a>
					<a href="http://www.jhga.gov.cn/" target="_blank"><img src="https://b3.hoopchina.com.cn/images/wl_wljga.png" alt="金华市公安局网络报警"></a>
                    <a href="http://www.zx110.org" target="_blank"><img src="https://b3.hoopchina.com.cn/images/wl_wlshzxw.png" alt="网络社会征信网"></a>
                    <a href="http://www.shjbzx.cn/" target="_blank"><img src="https://b3.hoopchina.com.cn/images/www_jubao.png" alt="上海网络举报图片"></a>
                    <a href="http://report.12377.cn:13225/toreportinputNormal_anis.do" target="_blank"><img src="https://b3.hoopchina.com.cn/images/www_cn_jubao.png" alt="有害信息举报图片"></a>
                    <img src="https://b3.hoopchina.com.cn/images/www_jubao.jpg" alt="虎扑举报图片"></div>
                        <img style="margin:0 auto;display: block;margin-top: 10px;max-width: 100%;" src="https://b3.hoopchina.com.cn/images/www_shwj_notice.jpg" alt="上海网警提示">
                </div>
        </div>
<script>
    _common.init({project:"sports"});
</script>
<!-- 马年换肤标识 -->
<script>
    var horseYearFlag = 0;
    var horseCurrent = new Date();
    var horseStart = new Date("Jan 29, 2014 15:00:00");
    var horseEnd = new Date("Feb 15, 2014 10:00:00");
    if(horseCurrent.getTime()>horseStart.getTime() && horseCurrent.getTime()<horseEnd.getTime())
    {
        var horseYearFlag = 1;
    }
</script>
<!-- 马年换肤标识 -->
<script src="//b3.hoopchina.com.cn/web/ad/skin/js/replaceSkin.v1.js" type="text/javascript"></script>
<!--非定向广告 -->
<script type="text/javascript" src="//orz.hupu.com/hupu/stream.js"></script>
<!--定向投放广告 -->
<!--<script type="text/javascript" src="http://b3.hoopchina.com.cn/web/ad/regional/js/choose-stream-ad.js"></script>-->

<input type="hidden"
       id="txtAdLinks"
       value="篮球比赛|https://nba.hupu.com/games,足球比赛|https://g.hupu.com/soccer/;球星战靴最新折扣|http://goto.hupu.com/?a=goClick&id=9965,进入NBA比赛中心» |https://nba.hupu.com/games;进入足球比赛中心»|https://g.hupu.com/soccer/;" />
<!--    value="篮球比赛|http://g.hupu.com/nba/,足球比赛|https://g.hupu.com/soccer/;进入NBA比赛中心» |http://g.hupu.com/nba;进入足球比赛中心»|https://g.hupu.com/soccer;" />-->



    <input type="hidden" id="url-match" value="//www-backend.hupu.com/global/match" />
    <input type="hidden" id="url-lingguang" value="//www-backend.hupu.com/global/lingguang" />
<input type="hidden" data-generate-time="2019-07-05 16:20:06" data-generator="robot" />
    <!--
    <div style="display: none;">
    <script type="text/javascript">
    var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
    document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F3d37bd93521c56eba4cc11e2353632e2' type='text/javascript'%3E%3C/script%3E"));
    </script>
    </div>-->
</div>

<!-- 94293：test论坛首页右下角1 类型：浮层广告位 尺寸：--->
<script type="text/javascript">//<![CDATA[
    ac_as_id = 94293;
    ac_format = 0;
    ac_mode = 1;
    ac_group_id = 1;
    ac_server_base_url = "afp.csbew.com/";
    //]]></script>
<script type='text/javascript'>
    (function() {
        var gads = document.createElement('script');
        var startDate = new Date().getTime();
        var endDate, loadDate;
        gads.async = true;
        gads.type = 'text/javascript';
        var useSSL = 'https:' == document.location.protocol;
        gads.src = (useSSL ? 'https:' : 'http:') +
        '//www.googletagservices.com/tag/js/gpt.js';
        var node = document.getElementsByTagName('script')[0];
        node.parentNode.insertBefore(gads, node);
    })();
</script>
</body>
</html>
<script type="text/javascript" src="//b3.hoopchina.com.cn/web/channel/www/js/hupu/homepage/match.js?201612231510"></script>
<script id="ad-template" type="text/x-hupu-template" >
    <a target="_blank" href="{{link}}">{{title}}</a>
</script>
<script type="text/javascript">
    lazyLoadImg.init();
</script>

<script type="text/javascript" src="//goto.hupu.com/js/c/56.js"></script>
<!-- 元旦换肤-->
<!-- 美孚小覆层广告 -->
<!--<script src="http://w3.hoopchina.com.cn/index/js/smallCenterSkin.js"></script>-->
